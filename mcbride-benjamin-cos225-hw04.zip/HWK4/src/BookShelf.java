import java.util.ArrayList;

public class BookShelf {
    public char initial;
    public ArrayList<Book> bookList;
    public final int SHELFSIZE = 8;

    //Getters and setters
    public void setinitial(char initial){
        this.initial = initial;
    }

    public char getinitial(){
        return initial;
    }

    public void setbooklist(ArrayList<Book> bookList){
        this.bookList = bookList;
    }

    public arrayList<book> getbooklist(){
        return bookList;
    }

    //Constructor
    public BookShelf(char initial){
        this.bookList = new ArrayList<Book>(SHELFSIZE);
        this.initial = initial;
        for(int i = 0;i < SHELFSIZE;i++){
            this.bookList.add(null);
        }
    }

    public void shelve(Book newBook){
        for(int i = 0;i < bookList.size();i++){
            if(bookList.get(i) == null){
                if(newBook.title.charAt(0) == initial){
                    bookList.set(i,newBook);
                    return;
                } else {
                    return;
                }
            }
        }
    }

    public void borrow(int i){
        bookList.set(i,null);
    }

    public String toString(){
        String output = "";
        for (int i = 0;i < bookList.size();i++){
            if (bookList.get(i) != null){
                output += (bookList.get(i).title + "   ");
            }
        }
        if(output == ""){
            output = "Empty";
        }
        return output;
    }
}
