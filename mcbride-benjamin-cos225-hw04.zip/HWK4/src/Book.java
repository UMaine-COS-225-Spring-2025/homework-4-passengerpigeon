public class Book {
    public String title;
    public String genre;

    //Constructor
    public Book(){
        title = null;
        genre = null;
    }

    //Parammed
    public Book(String title,String genre){
        this.title = title;
        this.genre = genre;
    }

    public String toString(){
        return title;
    }
}
