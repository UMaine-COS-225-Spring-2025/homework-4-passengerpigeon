public class LibraryTester {
    public static void main(String[] args){
        BookShelf shelfO = new BookShelf('O');
        BookShelf shelfT = new BookShelf('T');
        System.out.println(shelfO);
        System.out.println(shelfT);
        Book hotb = new Book("The Heart of the Betrayed","Crime");
        Book ohos = new Book("Our Hill of Stars","Fantasy");
        Book ooak = new Book("One of a Kind","Science Fiction");
        Book tvor = new Book("The Vision of Roses","Romance");
        System.out.println(hotb);
        System.out.println(ohos);
        System.out.println(ooak);
        System.out.println(tvor);
        shelfO.shelve(hotb);
        shelfO.shelve(ohos);
        shelfO.shelve(ooak);
        shelfO.shelve(tvor);
        shelfT.shelve(hotb);
        shelfT.shelve(ohos);
        shelfT.shelve(ooak);
        shelfT.shelve(tvor);
        System.out.println(shelfO);
        System.out.println(shelfT);
    }
}
